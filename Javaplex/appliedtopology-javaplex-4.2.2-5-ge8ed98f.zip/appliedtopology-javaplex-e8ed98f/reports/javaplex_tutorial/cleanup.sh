#!/bin/bash

rm javaplex_tutorial.aux
rm javaplex_tutorial.blg
rm javaplex_tutorial.log
rm javaplex_tutorial.out
rm javaplex_tutorial.bbl
rm javaplex_tutorial.toc
rm javaplex_tutorial.pdf
