public enum State {
  ADDPOINTS,
  MOVEBOARD,
  ANIMATE
};
