package edu.stanford.math.plex4.streams.filter;

public interface FilterFunction<T> {
	double evaluate(T point);
}
